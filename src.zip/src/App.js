import React from 'react';
import './App.css';
import AppRouter from './routes/AppRouter.jsx';

function App() {
  return (
    <div className="App">
      <AppRouter />
    </div>
  );
}

export default App;
